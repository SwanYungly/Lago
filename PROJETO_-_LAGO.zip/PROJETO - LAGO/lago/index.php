<?php
    header('location: LagoEventos/lagoEventos.php');
?>