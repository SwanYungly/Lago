<?php
$servidor="localhost";
$usuario="root";
$senha="";
$banco="lago";

$conexao=mysqli_connect($servidor,$usuario,$senha,$banco);
?>